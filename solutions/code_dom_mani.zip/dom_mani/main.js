//Hämtar ut alla list items <li> med TagName
var listItems = document.getElementsByTagName('li');

//Går igenom arrayen med <li>
for(var i = 0; i < listItems.length; i++){
	//Lägger till en event listener på varje <li>
	listItems[i].addEventListener("click", logger);
}

console.log(listItems);

function logger(){
		alert("Alerth! Seal the gate!!!!!");
		//this referar till html-elementet
		console.log(this.innerHTML);
		console.log(this.parentElement);	
}
logger();