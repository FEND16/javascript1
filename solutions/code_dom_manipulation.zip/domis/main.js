
//Funktion för att hämta ett element av ett visst ID
var myDiv = document.getElementById('myid');
//För att hämta en array av element efter en viss klass
var elements = document.getElementsByClassName('my-class');

//Man kan även hämta alla element av en viss typ av element med tagName
//Här hämtar vi t.ex. samliga divar i dokumentet
var myElements = document.getElementsTagName('div');

//Loggar ut alla element
console.log(elements);
//Loggar ut det enskilda elementet
console.log(myDiv);

//För att ändra ett elements innehåll kan vi använda .innerHTML
myDiv.innerHTML = "Tjena";

//Vi kan ändra enskilda elements css-egenskaper
myDiv.style.width = "200px";
myDiv.style.height = "200px";
myDiv.style.background = "red";


//Vi kan även skapa nya element med createElement
var myCoolElement = document.createElement('div');

//Vi kan skapa enskilda textnoder med createTextNode. 
var myText = document.createTextNode('Tjenamorselihejseli');

// Lägger till textnode i elementnode. myCoolElement blir parent till myText
myCoolElement.appendChild(myText);

//Lägger till själva elementet på sidan
document.body.appendChild(myCoolElement);



//myDiv är diven i HTML, refererar till samma div. Tilldelar onclick-egenskapen en
//anonym funktion som ska alerta "Hej";
myDiv.onclick = function(){
	alert('Hej');
};

//Vi kan även skapa en vanlig funktion som vi sedan kallar på i vår index.html
function clickFunction(){
	alert('Hej hej!');
}

//Man kan även använda metoden .addEventListener() för att lägga till en klick-funktion
//på ett speciellt element. Denna fungerar på samma sätt som onclick.
myDiv.addEventListener('click', function(){
	alert('Yooo');
});













